# NHF Portal

A production-ready full-stack web application with:

- React + Vite frontend
- Express + TypeScript API
- PostgreSQL + Drizzle ORM
- Paystack payment verification
- OpenAPI/Zod-generated API types

## Requirements

- Node.js 20+
- pnpm 10+
- PostgreSQL
- Paystack keys if payment verification is enabled

## Local setup

```bash
corepack enable
pnpm install
cp .env.example .env
pnpm db:push
pnpm run build
pnpm run start
```

The combined production server runs on `http://localhost:3000`.

For frontend-only development:

```bash
pnpm dev
```

Vite uses port `5173` by default.

## Environment variables

See `.env.example`.

Important:

- `DATABASE_URL` is required by the API.
- `PAYSTACK_SECRET_KEY` is required for real payment verification.
- `PAYSTACK_PUBLIC_KEY` is exposed to the browser through the API payment config endpoint.
- `VITE_API_URL` is only needed when the frontend and API are deployed separately.
- Never commit `.env` or real API keys.

## Deploying as one service

The repository includes a `Dockerfile`. Any Docker-compatible host can build and run it.

The container:

1. installs dependencies,
2. builds the frontend,
3. builds the API,
4. serves the frontend and `/api/*` from the same Node process.

Set the production environment variables on your hosting provider, especially `DATABASE_URL`, `PAYSTACK_PUBLIC_KEY`, and `PAYSTACK_SECRET_KEY`.

## Deploying frontend and API separately

Build the frontend with:

```bash
pnpm --filter @workspace/nhf-portal build
```

Set:

```text
VITE_API_URL=https://your-api-domain.example
```

when building the frontend. The API should allow the frontend origin through `CORS_ORIGIN`.

## GitHub

This repository intentionally does **not** include the Replit `.git` history or Replit agent/tooling directories. Commit the cleaned source to a new Git repository:

```bash
git init
git add .
git commit -m "Prepare project for GitHub deployment"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git
git push -u origin main
```

Do not commit `.env`, database credentials, Paystack secret keys, or other secrets.

## Project structure

```text
artifacts/
  api-server/       Express API
  nhf-portal/       React/Vite frontend
lib/
  api-client-react/ generated React API client
  api-spec/         OpenAPI specification
  api-zod/          generated Zod schemas
  db/               Drizzle/PostgreSQL database
scripts/             project scripts
```
