import { createRoot } from 'react-dom/client';
import { setBaseUrl } from '@workspace/api-client-react';

import App from './App';
import { ErrorBoundary } from '@/components/error-boundary';

import './index.css';

// For a separate frontend/API deployment, set VITE_API_URL to the API origin.
// Leave it empty when the frontend and API are served from the same origin.
const apiUrl = import.meta.env.VITE_API_URL?.trim();
if (apiUrl) {
  setBaseUrl(apiUrl.replace(/\/$/, ''));
}

createRoot(document.getElementById('root')!, {
  // Keeps caught errors off reportError(), which would raise the dev overlay.
  onCaughtError: (error, errorInfo) => {
    console.error(error, errorInfo.componentStack);
  },
}).render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>,
);
