import express, { type Express } from "express";
import path from "node:path";
import cors from "cors";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
const allowedOrigins = process.env.CORS_ORIGIN
  ?.split(",")
  .map((origin) => origin.trim())
  .filter(Boolean);

app.use(
  cors({
    origin: allowedOrigins?.length ? allowedOrigins : true,
    credentials: true,
  }),
);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/api", router);

// If STATIC_DIR is provided, the API server can host the Vite build too.
// This makes the project easy to deploy as one service.
const staticDir = process.env.STATIC_DIR;
if (staticDir) {
  const absoluteStaticDir = path.resolve(staticDir);
  app.use(express.static(absoluteStaticDir));
  app.get("*splat", (_req, res) => {
    res.sendFile(path.join(absoluteStaticDir, "index.html"));
  });
}

export default app;
